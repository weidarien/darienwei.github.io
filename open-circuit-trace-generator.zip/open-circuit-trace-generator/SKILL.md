---
name: open-circuit-trace-generator
description: Generate editable Excel voltage, equivalent-current (Ieq) and TEER traces from exported open-circuit LabChart CSV, TSV or TXT recordings using this portable Python tool. Use for repeated Ussing-chamber analysis with biphasic pulses, sample groups, drug times and blank calibration. Not for short-circuit Isc or direct binary .adicht decoding.
---

# Open-circuit trace generator

Use the included deterministic scripts instead of rebuilding the analysis. This portable edition needs Python 3.10+ and requirements.txt; it does not need a private runtime, API key or network access during analysis. Read README.md for one-time setup and references/input-format.md when creating settings.

## Run

1. Reuse an identified numeric export. For .adicht-only input, request a LabChart numeric export; do not pretend to decode the binary file.
2. Resolve time/voltage units, channel groups, exposed area, both current levels, drug times and TEER calibration from the user's information. Preserve confirmations for the same experiment. Example values are synthetic, not defaults for new experimental data.
3. With this folder's .venv Python (or an existing environment containing requirements.txt), run scripts/run.py --config /absolute/path/experiment.json --out /absolute/path/new-results-folder. Resolve script paths from this SKILL.md. --check-only checks inputs without building a workbook.
4. Read verification.json and Results.md, inspect affected plots and pulse-window figures, and report material flags and omitted values. Deliver only verified traces.xlsx. Existing results are never overwritten.

For direct human operation, use start.py. The browser form runs on a loopback server, and routine generation makes no AI calls. Asking an AI agent to run or review this skill still uses that agent.

## Calibration and scientific behavior

- Use the full bipolar span: current high − current low. −1 to +1 µA means 2 µA, not 1 µA.
- Pulse R (Ω) = 1000 × ΔVpp(mV) / ΔIpp(µA). TEER (Ω·cm²) = (pulse R − remaining blank in Ω) × area(cm²).
- Set teer.mode to pending when compensation is unknown; corrected TEER stays blank while pulse R remains available.
- Use already_compensated only when the user confirms no further blank subtraction is needed, including confirmed dummy-membrane calibration under matching solution conditions. This explicitly uses remaining blank 0 Ω; it does not assert that the physical solution has no resistance.
- Otherwise use subtract_blank with a measured common blank and optional per-channel overrides. Never subtract an already compensated blank twice. Do not infer one experiment's calibration for another.
- Ieq magnitude remains abs(baseline_mV) / ΔVpp(mV) × ΔIpp / area. TEER blank settings do not alter this existing Ieq method.
- Retain all raw voltage rows and their original time origin. Do not smooth, downsample, silently omit samples or remove finite flagged values.
- Invalid pulse heights produce blank measurements and intentional #N/A chart gaps. Nonpositive corrected TEER stays numeric and flagged. Group means require all samples at that pulse; do not silently change n.
- Automatic detection requires review when acquisition timing or waveform changes. Manual pulse times are supported in JSON.
- Preserve finalization: it independently verifies saved values and chart bindings against source numbers. Cached-value verification is separate from live recalculation; Excel recalculates formulas on opening.
- Formula edits update native charts in Excel; fixed axes and separate PNGs require a rerun for final figures. Group means do not establish statistical significance.

For routine repeats, run the saved configuration and summarize QC exceptions. Avoid loading whole raw files or recreating charts through the UI. Package changes require scripts/test_workflow.py and scripts/test_export.py with synthetic data.
