# Synthetic example only

This recording was generated mathematically by `scripts/make_example.py`. It contains no biological measurements, patient/donor information or copied experimental traces.

- 4,801 rows, 0–1,200 seconds, at 4 Hz.
- Four voltage channels, two illustrative groups, mV units.
- Area 0.5 cm²; negative/positive current −2/+2 µA (4 µA peak-to-peak).
- Thirty complete pulse cycles, starting at 10 s and recurring every 40 s.
- One fictional annotation at 600 s; it does not describe a real intervention.

`experiment.json` should produce 10 native editable Excel charts, with 120 verified Ieq values. All 4,801 raw rows should be retained. This example is for checking installation and learning the interface, not evidence about an experiment.

The separate automated tests deliberately introduce an invalid channel to verify blank measurement cells, chart gaps and complete-group averaging.
