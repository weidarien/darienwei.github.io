#!/bin/zsh
TRACE_PACKAGE_DIR="${0:A:h}"
TRACE_PYTHON="$TRACE_PACKAGE_DIR/.venv/bin/python"
if [[ ! -x "$TRACE_PYTHON" ]]; then
  print "One-time setup is needed. Follow the macOS instructions in README.md."
  read -r "?Press Return to close."
  exit 1
fi
"$TRACE_PYTHON" "$TRACE_PACKAGE_DIR/start.py"
TRACE_EXIT_CODE=$?
if [[ $TRACE_EXIT_CODE -ne 0 ]]; then
  read -r "?The generator stopped. Read the message above, then press Return."
fi
exit $TRACE_EXIT_CODE
