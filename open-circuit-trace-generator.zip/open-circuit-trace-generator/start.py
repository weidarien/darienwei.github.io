#!/usr/bin/env python3
"""Start the local generator using this folder's installed dependencies."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
if sys.version_info < (3, 10):
    raise SystemExit("Python 3.10 or newer is required. See README.md.")
missing = []
for module in ("numpy", "matplotlib", "xlsxwriter", "openpyxl", "lxml"):
    try:
        __import__(module)
    except ImportError:
        missing.append(module)
if missing:
    raise SystemExit("Missing dependencies: " + ", ".join(missing) +
                     ". Complete the one-time setup in README.md using this Python environment.")
raise SystemExit(subprocess.call([sys.executable, str(ROOT / "scripts/serve.py"),
                                 "--output-root", str(ROOT / "results"), *sys.argv[1:]]))
