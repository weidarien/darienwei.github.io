"""Repair native chart serialization and validate every saved raw, Ieq and TEER value."""
from pathlib import Path
import zipfile,json,math,re,sys
from lxml import etree as E
from openpyxl import load_workbook
from openpyxl.utils.cell import column_index_from_string

OUT=Path(sys.argv[1]).resolve()
target=OUT/'traces.xlsx'
specs=json.loads((OUT/'chart_specs.json').read_text())
data=json.loads((OUT/'analysis.json').read_text())['runs']
NS={'c':'http://schemas.openxmlformats.org/drawingml/2006/chart','a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
def tag(prefix,name):return '{'+NS[prefix]+'}'+name
def child(p,prefix,name,**attrs):return E.SubElement(p,tag(prefix,name),**{k:str(v) for k,v in attrs.items()})

with zipfile.ZipFile(target) as z:files={n:z.read(n) for n in z.namelist()}
cached=load_workbook(target,read_only=True,data_only=True)
cells={s.title:list(s.values) for s in cached}
cached.close()
def values_for(formula):
    m=re.fullmatch(r"'([^']+)'!\$([A-Z]+)\$(\d+):\$([A-Z]+)\$(\d+)",formula)
    assert m,formula
    sheet,col,start,endcol,end=m.groups()
    assert col==endcol
    c=column_index_from_string(col)-1
    vals=[cells[sheet][i-1][c] for i in range(int(start),int(end)+1)]
    assert all(v in (None,'','#N/A') or (isinstance(v,(int,float)) and math.isfinite(v)) for v in vals),formula
    return vals
charts=sorted([n for n in files if re.fullmatch(r'xl/(?:drawings/)?charts/chart\d+\.xml',n)],key=lambda n:int(n.split('chart')[-1].split('.')[0]))
assert len(charts)==len(specs)==sum(3*(len(r['channels'])+1) for r in data)
for name,spec in zip(charts,specs):
    root=E.fromstring(files[name]); plot=root.find('.//c:plotArea',NS)
    scatter=plot.find('c:scatterChart',NS); assert scatter is not None
    # Artifact-tool's scatter exporter defaults to marker-only. Preserve its
    # range bindings and all points while explicitly selecting straight lines.
    scatter.find('c:scatterStyle',NS).set('val','lineMarker')
    series=scatter.findall('c:ser',NS)
    assert len(series)==spec['seriesCount']+spec['events']+(spec['type']=='Voltage')
    for i,ser in enumerate(series):
        for axis,binding in [('xVal','x'),('yVal','y')]:
            node=ser.find('c:'+axis,NS)
            assert node is not None
            for elem in list(node):node.remove(elem)
            ref=child(node,'c','numRef')
            formula=spec['bindings'][i][binding]
            child(ref,'c','f').text=formula
            cache=child(ref,'c','numCache')
            child(cache,'c','formatCode').text='General'
            vals=values_for(formula)
            child(cache,'c','ptCount',val=len(vals))
            for idx,val in enumerate(vals):
                if val in (None,'','#N/A'):continue
                child(child(cache,'c','pt',idx=idx),'c','v').text=str(val)
        symbol=ser.find('c:marker/c:symbol',NS)
        if symbol is not None and (spec['type']=='Voltage' or spec['overlay'] or i>=spec['seriesCount']):symbol.set('val','none')
        if spec['type'] in ('Ieq','TEER') and not spec['overlay'] and i<spec['seriesCount']:
            marker=ser.find('c:marker',NS)
            for old in marker.findall('c:spPr',NS):marker.remove(old)
            shape=child(marker,'c','spPr')
            child(child(shape,'a','solidFill'),'a','srgbClr',val='000000')
            child(child(child(shape,'a','ln',w=6350),'a','solidFill'),'a','srgbClr',val='000000')
        if spec['type']=='Voltage' and i==spec['seriesCount']:
            dash=ser.find('c:spPr/a:ln/a:prstDash',NS)
            if dash is not None:dash.set('val','sysDot')
        labels=ser.find('c:dLbls',NS)
        if labels is not None:
            for label in list(labels):
                if label.tag==tag('c','dLbl') and label.find('c:idx',NS).get('val')=='0':labels.remove(label)
            hidden=E.Element(tag('c','dLbl'));child(hidden,'c','idx',val=0);child(hidden,'c','delete',val=1)
            labels.insert(0,hidden)
            for flag in ['showLegendKey','showVal','showCatName','showSerName','showPercent','showBubbleSize','showLeaderLines']:
                el=labels.find('c:'+flag,NS)
                if el is None:el=child(labels,'c',flag)
                el.set('val','0')
    axes=plot.findall('c:valAx',NS)
    assert len(axes)==2
    for ax in axes:
        position=ax.find('c:axPos',NS).get('val')
        for old in ax.findall('c:crosses',NS)+ax.findall('c:crossesAt',NS):ax.remove(old)
        cross=E.Element(tag('c','crossesAt'),val=str(spec['xmin'] if position in ('l','r') else spec['ymin']))
        ax.insert(list(ax).index(ax.find('c:crossAx',NS))+1,cross)
    legend=root.find('.//c:legend',NS)
    if legend is not None:
        for old in legend.findall('c:legendEntry',NS):legend.remove(old)
        insert=1
        for i in range(spec['seriesCount'],len(series)):
            ent=E.Element(tag('c','legendEntry'));child(ent,'c','idx',val=i);child(ent,'c','delete',val=1)
            legend.insert(insert,ent);insert+=1
    sp=root.find('c:spPr',NS)
    if sp is None:sp=child(root,'c','spPr')
    ln=sp.find('a:ln',NS)
    if ln is None:ln=child(sp,'a','ln',w=12700)
    else:
        for element in list(ln):ln.remove(element)
        ln.set('w','12700')
    fill=child(ln,'a','solidFill');child(fill,'a','srgbClr',val='000000')
    files[name]=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
sheetns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
for n in range(1,len(data)*3+1):
    name=f'xl/worksheets/sheet{n}.xml'
    root=E.fromstring(files[name])
    for view in root.findall('s:sheetViews/s:sheetView',sheetns):view.set('zoomScale','60')
    files[name]=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
temp=OUT/'verified_export.tmp'
with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
    for name,body in files.items():z.writestr(name,body)
temp.replace(target)

wb=load_workbook(target,read_only=True,data_only=True)
report={'status':'verified','native_charts':len(charts),'runs':[],'errors':[]}
expected_chart_gaps=set()
def near(a,b):
    assert isinstance(a,(int,float)) and math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-8),(a,b)
for ri,run in enumerate(data):
    nc=len(run['channels']);pc=len(run['pulses'])
    settings=wb['Settings and method']
    near(settings.cell(6+ri,2).value,run['area'])
    near(settings.cell(6+ri,5).value,run['current_step'])
    raw=wb[run['run']+'_Voltage_Raw']
    observed=list(raw.iter_rows(min_row=7,max_row=len(run['rows'])+6,max_col=nc+1,values_only=True))
    assert all(list(a)==b for a,b in zip(observed,run['rows'])) and len(observed)==len(run['rows'])
    groups=[[i for i,c in enumerate(run['channels']) if c['group']==g] for g in run['groups']]
    means=list(raw.iter_rows(min_row=7,max_row=len(run['rows'])+6,min_col=nc+3,max_col=nc+2+len(groups),values_only=True))
    for source,saved in zip(run['rows'],means):
        for indices,mean in zip(groups,saved):near(mean,sum(source[i+1] for i in indices)/len(indices))
    calc=wb[run['run']+'_Ieq_Calc']
    saved=list(calc.iter_rows(min_row=7,max_row=pc*nc+6,min_col=8,max_col=13,values_only=True))
    valid_count=0
    for p,pulse in enumerate(run['pulses']):
        for c in range(nc):
            base,low,high,dv,rte,ieq=saved[p*nc+c]
            # Independent recomputation from the original CSV values, not cached analysis outputs.
            original=run['rows']
            factor=run['unit_factor']
            baseline=[original[i][c+1]*factor for i in range(pulse['baseline_start'],pulse['baseline_end']+1)]
            window=[original[i][c+1]*factor for i in range(pulse['start'],pulse['end']+1)]
            expected_base=sum(baseline)/len(baseline);expected_dv=max(window)-min(window)
            near(base,expected_base);near(low,min(window));near(high,max(window));near(dv,expected_dv)
            if expected_dv<=run['analysis']['minimum_delta_mV']:
                assert ieq in (None,'') and rte in (None,'')
            else:
                near(ieq,abs(expected_base)/expected_dv*run['current_step']/run['area'])
                near(rte,1000*expected_dv*run['area']/run['current_step'])
                valid_count+=1
    plot=list(calc.iter_rows(min_row=7,max_row=pc+6,min_col=16,max_col=16+nc+len(groups),values_only=True))
    for p,row in enumerate(plot):
        near(row[0],run['pulses'][p]['time'])
        for c in range(nc):
            measurement=saved[p*nc+c][5]
            if measurement in (None,''):
                assert row[c+1]=='#N/A',(run['run'],p,c,row[c+1])
                expected_chart_gaps.add((calc.title,7+p,17+c))
            else:near(row[c+1],measurement)
        for gi,indices in enumerate(groups):
            values=[row[i+1] for i in indices]
            mean=row[1+nc+gi]
            if any(x=='#N/A' for x in values):
                assert mean=='#N/A'
                expected_chart_gaps.add((calc.title,7+p,17+nc+gi))
            else:near(mean,sum(values)/len(indices))
    teer=wb[run['run']+'_TEER_Calc']
    teer_saved=list(teer.iter_rows(min_row=7,max_row=pc*nc+6,max_col=7,values_only=True))
    teer_count=0;nonpositive=0
    for p,pulse in enumerate(run['pulses']):
        for c,channel in enumerate(run['channels']):
            cycle,time,label,resistance,blank,value,note=teer_saved[p*nc+c]
            near(cycle,p+1);near(time,pulse['time']);assert label==channel['label']
            window=[run['rows'][i][c+1]*run['unit_factor'] for i in range(pulse['start'],pulse['end']+1)]
            dv=max(window)-min(window);expected_blank=run['teer']['blank_ohm'][c]
            if expected_blank is None:assert blank in (None,'')
            else:near(blank,expected_blank)
            if dv<=run['analysis']['minimum_delta_mV']:
                assert resistance in (None,'') and value in (None,'')
                assert note=='Invalid pulse or current/area calibration'
            else:
                expected_r=1000*dv/run['current_step'];near(resistance,expected_r)
                if expected_blank is None:
                    assert value in (None,'') and note=='Pending blank calibration'
                else:
                    expected=(expected_r-expected_blank)*run['area'];near(value,expected);teer_count+=1
                    if expected<=0:
                        nonpositive+=1;assert note=='Nonpositive TEER: review blank and pulse'
                    else:assert note in (None,'')
    teer_plot=list(teer.iter_rows(min_row=7,max_row=pc+6,min_col=10,max_col=10+nc+len(groups),values_only=True))
    for p,row in enumerate(teer_plot):
        near(row[0],run['pulses'][p]['time'])
        for c in range(nc):
            measurement=teer_saved[p*nc+c][5]
            if measurement in (None,''):
                assert row[c+1]=='#N/A';expected_chart_gaps.add((teer.title,7+p,11+c))
            else:near(row[c+1],measurement)
        for gi,indices in enumerate(groups):
            values=[row[i+1] for i in indices];mean=row[1+nc+gi]
            if any(x=='#N/A' for x in values):
                assert mean=='#N/A';expected_chart_gaps.add((teer.title,7+p,11+nc+gi))
            else:near(mean,sum(values)/len(indices))
    report['runs'].append({'id':run['run'],'raw_rows_verified':len(observed),'pulse_cycles':pc,
                          'Ieq_values_verified':valid_count,'Ieq_values_omitted':pc*nc-valid_count,
                          'TEER_values_verified':teer_count,'TEER_values_unavailable':pc*nc-teer_count,
                          'TEER_nonpositive_values':nonpositive,'TEER_calibration_mode':run['teer']['mode'],
                          'warnings':run['warnings'],'excluded_pulses':run['excluded']})
for sheet in wb:
    for row in sheet:
        for cell in row:
            if cell.data_type=='e' and not (cell.value=='#N/A' and (sheet.title,cell.row,cell.column) in expected_chart_gaps):
                report['errors'].append([sheet.title,cell.coordinate,cell.value])
wb.close()
report['intentional_chart_gap_cells']=len(expected_chart_gaps)
assert not report['errors'],report['errors']
(OUT/'verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'status':report['status'],'charts':len(charts),'Ieq_values_verified':sum(r['Ieq_values_verified'] for r in report['runs']),
                  'TEER_values_verified':sum(r['TEER_values_verified'] for r in report['runs'])}))
