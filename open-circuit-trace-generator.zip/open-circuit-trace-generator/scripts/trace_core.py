"""Deterministic open-circuit analysis. No network or AI calls."""
from pathlib import Path
import csv
import hashlib
import io
import json
import math
import re
import numpy as np

VERSION = "1.0"
DEFAULT_ANALYSIS = {
    "reference_channel": 0,
    "negative_threshold_mV": 0.12,
    "median_window_s": 6.25,
    "minimum_phase_samples": 2,
    "pulse_window_s": 2.25,
    "baseline_start_before_s": 2.0,
    "baseline_end_before_s": 0.5,
    "annotation_flag_s": 5.0,
    "asymmetry_fraction": 0.15,
    "minimum_delta_mV": 0.000001,
}

def require(ok, message):
    if not ok:
        raise ValueError(message)

def positive(value, name):
    require(isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and value > 0, name + " must be a positive number.")
    return float(value)

def read_csv(path, spec):
    text = path.read_text(encoding="utf-8-sig")
    skip = spec.get("skip_header_lines", 0)
    require(isinstance(skip, int) and 0 <= skip <= 100, "skip_header_lines must be 0–100.")
    lines = text.splitlines()[skip:]
    delimiter = spec.get("delimiter")
    if delimiter is None:
        try:
            delimiter = csv.Sniffer().sniff("\n".join(lines[:20]), delimiters=",\t;").delimiter
        except csv.Error:
            delimiter = ","
    require(delimiter in (",", "\t", ";"), "Use comma, tab or semicolon delimiters.")
    reader = csv.reader(lines, delimiter=delimiter)
    try:
        headers = [v.strip() for v in next(reader)]
    except StopIteration:
        raise ValueError("The data file is empty.")
    require(len(set(headers)) == len(headers), "CSV column names must be unique.")
    columns = [spec.get("time_column", "Time_s")] + [c["column"] for c in spec["channels"]]
    missing = [c for c in columns if c not in headers]
    require(not missing, "Missing CSV columns: " + ", ".join(missing))
    idx = [headers.index(c) for c in columns]
    rows = []
    for line, row in enumerate(reader, skip + 2):
        if not row or all(not x.strip() for x in row):
            continue
        require(len(row) == len(headers), f"CSV line {line}: column count does not match the header.")
        try:
            vals = [float(row[i].strip()) for i in idx]
        except ValueError:
            raise ValueError(f"CSV line {line}: selected time/voltage cells must be numeric.")
        require(all(math.isfinite(x) for x in vals), f"CSV line {line}: missing or non-finite data.")
        rows.append(vals)
    require(30 <= len(rows) <= 100000, "Each recording must have 30–100,000 rows. Split long recordings explicitly; data are never downsampled.")
    return np.asarray(rows, dtype=float)

def analyze_recording(spec, base_dir):
    name = spec.get("id", "")
    require(bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,14}", name)),
            "Recording id must be 1–15 letters, digits, underscores or hyphens.")
    path = (base_dir / spec["file"]).resolve()
    require(path.suffix.lower() in (".csv", ".tsv", ".txt"), "Use an exported CSV/TSV/TXT file. Binary .adicht files cannot be read by this tool.")
    require(path.is_file(), "Data file not found: " + str(path))
    channels = spec.get("channels", [])
    require(1 <= len(channels) <= 12, "Configure 1–12 voltage channels per recording.")
    for c in channels:
        require(all(isinstance(c.get(k), str) and c[k].strip() for k in ("column", "label", "group")),
                "Every channel needs column, label and group text.")
        require(max(len(c[k]) for k in ("label", "group")) <= 50, "Sample and group labels must be at most 50 characters.")
    require(len({c["column"] for c in channels}) == len(channels), "A CSV channel cannot be assigned twice.")
    require(len({c["label"] for c in channels}) == len(channels), "Sample labels must be unique within each recording.")
    groups = list(dict.fromkeys(c["group"] for c in channels))
    require(len(groups) <= 4, "Use at most four groups per recording.")
    unit = spec.get("voltage_units")
    require(unit in ("mV", "V"), "Specify voltage_units as mV or V.")
    area = positive(spec.get("area_cm2"), "area_cm2")
    lo, hi = spec.get("current_low_uA"), spec.get("current_high_uA")
    require(all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in (lo, hi)),
            "Specify both current_low_uA and current_high_uA.")
    require(lo < 0 < hi, "This method requires biphasic current pulses: low < 0 < high.")
    step = hi - lo
    rows = read_csv(path, spec)
    t = rows[:, 0]
    dt = float(np.median(np.diff(t)))
    require(dt > 0 and bool(np.all(np.diff(t) > 0)), "Time must be strictly increasing, in seconds.")
    require(bool(np.allclose(np.diff(t), dt, rtol=0.005, atol=0.000001)),
            "Time intervals are uneven or contain gaps. This pulse method requires uniform sampling.")
    factor = 1000 if unit == "V" else 1
    v = rows[:, 1:] * factor
    params = {**DEFAULT_ANALYSIS, **spec.get("analysis", {})}
    require(not (set(params) - set(DEFAULT_ANALYSIS)), "Unknown analysis setting.")
    ref = params["reference_channel"]
    require(isinstance(ref, int) and 0 <= ref < len(channels), "reference_channel is a zero-based index into channels.")
    for key in DEFAULT_ANALYSIS:
        if key != "reference_channel":
            positive(params[key], key)
    require(isinstance(params["minimum_phase_samples"], int), "minimum_phase_samples must be an integer.")
    require(params["baseline_start_before_s"] > params["baseline_end_before_s"],
            "Baseline start must be farther before the pulse than baseline end.")
    # Window boundaries must be expressible at the acquisition rate.
    offsets = {}
    for key in ("pulse_window_s", "baseline_start_before_s", "baseline_end_before_s"):
        q = params[key] / dt
        require(abs(q - round(q)) < 0.02, key + " must be a multiple of the sample interval.")
        offsets[key] = int(round(q))
    require(offsets["pulse_window_s"] >= 2, "The pulse window needs at least three acquired samples.")
    median_n = max(3, int(round(params["median_window_s"] / dt)))
    if median_n % 2 == 0:
        median_n += 1
    require(median_n <= 2001, "Median window is too large for this sampling rate; configure median_window_s.")
    require(median_n > offsets["pulse_window_s"], "median_window_s must exceed pulse_window_s.")
    events = []
    for e in spec.get("events", []):
        require(isinstance(e.get("label"), str) and 0 < len(e["label"]) <= 30, "Each event needs a label of 1–30 characters.")
        x = e.get("time_s")
        require(isinstance(x, (int, float)) and math.isfinite(x) and t[0] <= x <= t[-1],
                "Drug times must fall within the recording and use its time origin.")
        events.append([e["label"], float(x)])
    events.sort(key=lambda e: e[1])
    if "pulse_onsets_s" in spec:
        onset_times = spec["pulse_onsets_s"]
        require(isinstance(onset_times, list) and len(onset_times) > 0, "pulse_onsets_s must be a nonempty list.")
        starts = []
        for x in onset_times:
            require(isinstance(x, (int, float)) and math.isfinite(x) and t[0] <= x <= t[-1], "Manual pulse onset is outside the recording.")
            i = int(np.argmin(abs(t - x)))
            require(abs(t[i] - x) <= max(dt * .02, 1e-6), "Manual pulse onsets must match recorded sample times.")
            starts.append(i)
        require(starts == sorted(set(starts)), "Manual pulse onsets must be unique and ascending.")
        detector = "Manual pulse onset times"
    else:
        # Chunked running median prevents an unbounded temporary matrix.
        padded = np.pad(v[:, ref], median_n // 2, mode="edge")
        windows = np.lib.stride_tricks.sliding_window_view(padded, median_n)
        median = np.concatenate([np.median(windows[i:i+2000], axis=1) for i in range(0, len(v), 2000)])
        candidates = np.where(v[:, ref] - median < -params["negative_threshold_mV"])[0]
        groups_idx = np.split(candidates, np.where(np.diff(candidates) > 1)[0] + 1)
        starts = [int(g[0]) for g in groups_idx if len(g) >= params["minimum_phase_samples"]]
        detector = "Negative deflection from centered running median"
    pulses, excluded = [], []
    for n, s in enumerate(starts):
        end = s + offsets["pulse_window_s"]
        b0, b1 = s - offsets["baseline_start_before_s"], s - offsets["baseline_end_before_s"]
        if b0 < 0 or b1 < b0 or end >= len(v):
            excluded.append({"time_s": float(t[s]), "reason": "Incomplete baseline or pulse window"})
            continue
        if n + 1 < len(starts) and starts[n + 1] <= end:
            raise ValueError("Detected pulse windows overlap. Review reference channel, threshold or pulse window.")
        baseline = v[b0:b1+1].mean(axis=0)
        low = v[s:end+1].min(axis=0)
        high = v[s:end+1].max(axis=0)
        delta = high - low
        imbalance = np.divide(abs((high + low)/2 - baseline), delta,
                              out=np.full_like(delta, 1e9), where=delta > 0)
        valid = delta > params["minimum_delta_mV"]
        flags = []
        for c in range(len(channels)):
            f = []
            if any(abs(t[s] - e[1]) <= params["annotation_flag_s"] for e in events):
                f.append("Near drug annotation")
            if imbalance[c] > params["asymmetry_fraction"]:
                f.append("Pulse asymmetry / baseline drift")
            if not valid[c]:
                f.append("Invalid pulse height; Ieq omitted")
            if not (low[c] < baseline[c] < high[c]):
                f.append("Both pulse phases not resolved around baseline")
            flags.append("; ".join(f))
        ieq = [float(abs(baseline[c])/delta[c]*step/area) if valid[c] else None for c in range(len(channels))]
        pulses.append({"start": s, "end": end, "baseline_start": b0, "baseline_end": b1,
                       "time": float(t[s]), "base": baseline.tolist(), "low": low.tolist(),
                       "high": high.tolist(), "dv": delta.tolist(), "ieq": ieq, "flags": flags})
    require(bool(pulses), "No complete pulses detected. Review the pulse settings or supply manual onset times.")
    warnings = []
    intervals = np.diff([p["time"] for p in pulses])
    if len(intervals) and (intervals.max() > 1.5 * np.median(intervals) or intervals.min() < .5 * np.median(intervals)):
        warnings.append("Pulse spacing is irregular; inspect possible missed or extra detections.")
    if len(pulses) < 3:
        warnings.append("Fewer than three complete pulse cycles.")
    if excluded:
        warnings.append(f"{len(excluded)} incomplete pulse windows omitted from Ieq; all voltage rows retained.")
    flagged = sum(bool(x) for p in pulses for x in p["flags"])
    if flagged:
        warnings.append(f"{flagged} sample/pulse measurements need review; flagged finite measurements remain included.")
    return {
        "run": name, "title": spec.get("title", name), "source": path.name,
        "source_path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "channels": channels, "groups": groups, "area": area, "current_low": lo, "current_high": hi,
        "current_step": step, "unit": unit, "unit_factor": factor, "sample_interval": dt,
        "rows": rows.tolist(), "pulses": pulses, "events": events, "analysis": params,
        "detector": detector, "effective_median_samples": median_n, "excluded": excluded, "warnings": warnings,
    }

def prepare(config, base_dir):
    require(config.get("schema_version") == 1, "Use schema_version: 1.")
    specs = config.get("recordings", [])
    require(isinstance(specs, list) and 1 <= len(specs) <= 8, "Supply 1–8 recordings.")
    merged = [{**config.get("defaults", {}), **s} for s in specs]
    require(len({s.get("id", "").lower() for s in merged}) == len(merged), "Recording ids must be unique, ignoring case.")
    return {"version": VERSION, "title": config.get("title", "Open-circuit traces"),
            "runs": [analyze_recording(s, base_dir) for s in merged]}

def plots(data, out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    colors = ["#111111", "#C62828", "#2563EB", "#15803D"]
    for run in data["runs"]:
        rows = np.asarray(run["rows"])
        n = len(run["channels"])
        panel_rows = math.ceil(n/3)
        for kind in ("Voltage", "Ieq"):
            fig = plt.figure(figsize=(15, 3.1*panel_rows+4))
            grid = fig.add_gridspec(panel_rows+1, 3)
            t = rows[:, 0] if kind == "Voltage" else np.array([p["time"] for p in run["pulses"]])
            y = rows[:, 1:] if kind == "Voltage" else np.array([[np.nan if x is None else x for x in p["ieq"]] for p in run["pulses"]])
            xmax = max(2000, math.ceil(t[-1]/500)*500)
            group_limits = {}
            for g in run["groups"]:
                indices = [i for i,c in enumerate(run["channels"]) if c["group"] == g]
                vals = y[:, indices]
                finite = vals[np.isfinite(vals)]
                if kind == "Voltage":
                    low, high = min(float(finite.min()) if finite.size else 0, 0), max(float(finite.max()) if finite.size else 1, 0)
                    pad = max((high-low)*.12, .1/run["unit_factor"])
                    group_limits[g] = (low-pad, high+pad)
                else:
                    group_limits[g] = (0, max(10, math.ceil((float(finite.max()) if finite.size else 1)*1.15/10)*10))
            axes = []
            for i,c in enumerate(run["channels"]):
                ax = fig.add_subplot(grid[i//3, i%3])
                ax.plot(t, y[:, i], color="black", linewidth=.65, marker="s" if kind == "Ieq" else None, markersize=1.5)
                ax.set_title(c["label"]+" ("+c["group"]+")", fontsize=10)
                ax.set_ylim(*group_limits[c["group"]])
                axes.append(ax)
            ax = fig.add_subplot(grid[-1, :])
            for g,color in zip(run["groups"],colors):
                indices = [i for i,c in enumerate(run["channels"]) if c["group"] == g]
                ax.plot(t, np.mean(y[:, indices], axis=1), color=color, linewidth=.8, label=g+" (n="+str(len(indices))+")")
            ax.set_title("Group means; no statistical test", fontsize=11)
            ax.set_ylim(min(x[0] for x in group_limits.values()), max(x[1] for x in group_limits.values()))
            ax.legend(loc="upper right", fontsize=9, frameon=False)
            axes.append(ax)
            for ax in axes:
                ax.set_xlim(min(0, float(t[0])), xmax)
                ax.set_xlabel("Time (s)", fontsize=9)
                ax.set_ylabel("Vte ("+run["unit"]+")" if kind == "Voltage" else "Ieq magnitude (µA/cm²)", fontsize=9)
                if kind == "Voltage":
                    ax.axhline(0, color="black", linestyle=":", linewidth=.5)
                low, high = ax.get_ylim()
                for label,time in run["events"]:
                    ax.axvline(time, color="#A0A0A0", linestyle="--", linewidth=.5)
                    ax.text(time, high-(high-low)*.04, label, fontsize=7, ha="center", va="top", rotation=90 if len(run["events"])>6 else 0)
                ax.spines[["top","right"]].set_visible(False)
                ax.tick_params(labelsize=8)
            fig.suptitle(run["title"]+" — "+kind, fontsize=14)
            fig.tight_layout(rect=(0,0,1,.96))
            fig.savefig(out/(run["run"]+"_"+kind+".png"), dpi=140)
            plt.close(fig)
        fig,axes = plt.subplots(3,1,figsize=(13,8))
        centers = [run["pulses"][i]["time"] for i in sorted(set([0,len(run["pulses"])//2,len(run["pulses"])-1]))]
        for ax,center in zip(axes, centers):
            mask = (rows[:,0] >= center-5) & (rows[:,0] <= center+15)
            for i,c in enumerate(run["channels"]):
                ax.plot(rows[mask,0], rows[mask,i+1], linewidth=.8, label=c["label"])
            for p in run["pulses"]:
                if center-5 <= p["time"] <= center+15:
                    ax.axvspan(rows[p["start"],0], rows[p["end"],0], color="#D3E4F0", alpha=.35)
                    ax.axvspan(rows[p["baseline_start"],0], rows[p["baseline_end"],0], color="#CDE7CF", alpha=.4)
            ax.set_ylabel("Vte ("+run["unit"]+")")
            ax.set_xlabel("Time (s)")
            ax.legend(fontsize=7, ncol=min(n,6))
        fig.suptitle("Pulse review: blue = pulse window; green = baseline")
        fig.tight_layout(rect=(0,0,1,.96))
        fig.savefig(out/(run["run"]+"_pulse_review.png"), dpi=130)
        plt.close(fig)
