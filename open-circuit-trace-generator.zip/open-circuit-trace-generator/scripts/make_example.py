"""Create deterministic, entirely synthetic teaching data; no research inputs."""
from pathlib import Path
import csv
import json
import math

def create_example(folder):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    data_path = folder / "synthetic-recording.csv"
    config_path = folder / "experiment.json"
    if data_path.exists() or config_path.exists():
        raise ValueError("Example files already exist; choose an empty output folder.")
    with data_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["Time_s", "Ch1", "Ch2", "Ch3", "Ch4"])
        for i in range(4801):
            t = i / 4
            phase = (i - 40) % 160
            values = []
            for channel in range(4):
                baseline = -(1.5 + channel * .35) - .25 * math.tanh((t - 600) / 80)
                baseline += .012 * math.sin(t / 25 + channel)
                pulse = -.5 if phase in (0, 1) else .5 if phase in (2, 3) else 0
                values.append(round(baseline + pulse * (1 + channel * .15), 6))
            writer.writerow([t, *values])
    config = {"schema_version": 1, "title": "SYNTHETIC demonstration — not research data",
              "recordings": [{"id": "SYNTHETIC", "title": "Synthetic example", "file": data_path.name,
                  "time_column": "Time_s", "voltage_units": "mV", "area_cm2": .5,
                  "current_low_uA": -2, "current_high_uA": 2,
                  "teer": {"mode": "subtract_blank", "blank_ohm": 50},
                  "channels": [{"column": "Ch" + str(i + 1), "label": "Sample " + str(i + 1),
                                "group": "Group A" if i < 2 else "Group B"} for i in range(4)],
                  "events": [{"label": "Example event", "time_s": 600}]}]}
    config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    return config_path

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    print(create_example(parser.parse_args().out))
