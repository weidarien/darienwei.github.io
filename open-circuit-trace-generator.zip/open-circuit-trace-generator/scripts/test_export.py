"""End-to-end synthetic export checks; never reads research files."""
from pathlib import Path
import copy
import json
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
import zipfile
from lxml import etree as E
from openpyxl import load_workbook
from run import generate
from serve import make_server
from test_workflow import fixture

class ExportChecks(unittest.TestCase):
    def test_batch_values_formulas_and_chart_gaps(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            spec = fixture(root)
            second = copy.deepcopy(spec)
            second.update(id="SECOND", area_cm2=1)
            settings = root / "experiment.json"
            settings.write_text(json.dumps({"schema_version": 1, "recordings": [spec, second]}), encoding="utf-8")
            out = generate(settings, root / "results")
            report = json.loads((out / "verification.json").read_text())
            self.assertEqual(report["status"], "verified")
            self.assertEqual(report["native_charts"], 20)
            self.assertEqual(report["intentional_chart_gap_cells"], 16)
            self.assertEqual([r["Ieq_values_verified"] for r in report["runs"]], [12, 12])
            self.assertEqual([r["Ieq_values_omitted"] for r in report["runs"]], [4, 4])
            wb = load_workbook(out / "traces.xlsx", read_only=True, data_only=False)
            self.assertIn("'Settings and method'!$B$6", wb["UNIT_TEST_Ieq_Calc"]["M7"].value)
            self.assertIn("'Settings and method'!$B$7", wb["SECOND_Ieq_Calc"]["M7"].value)
            self.assertIn("NA()", wb["UNIT_TEST_Ieq_Calc"]["T7"].value)
            self.assertIn("COUNT(T7", wb["UNIT_TEST_Ieq_Calc"]["V7"].value.replace("S7,", ""))
            wb.close()
            values = load_workbook(out / "traces.xlsx", read_only=True, data_only=True)
            self.assertAlmostEqual(values["UNIT_TEST_Ieq_Calc"]["M7"].value, 16)
            self.assertAlmostEqual(values["SECOND_Ieq_Calc"]["M7"].value, 8)
            self.assertEqual(values["UNIT_TEST_Ieq_Calc"]["T7"].value, "#N/A")
            values.close()
            ns = {"c": "http://schemas.openxmlformats.org/drawingml/2006/chart"}
            with zipfile.ZipFile(out / "traces.xlsx") as archive:
                gaps_checked = 0
                for name in archive.namelist():
                    if not name.startswith("xl/charts/chart") or not name.endswith(".xml"):
                        continue
                    tree = E.fromstring(archive.read(name))
                    for series in tree.findall(".//c:ser", ns):
                        formula = series.find("c:yVal/c:numRef/c:f", ns).text
                        if "_Ieq_Calc'!$T$" in formula or "_Ieq_Calc'!$V$" in formula:
                            self.assertEqual(len(series.findall("c:yVal/c:numRef/c:numCache/c:pt", ns)), 0)
                            gaps_checked += 1
                self.assertEqual(gaps_checked, 4)
            with self.assertRaises(ValueError):
                generate(settings, out)

    def test_local_server_guards_and_form(self):
        with tempfile.TemporaryDirectory() as folder:
            server, url = make_server(folder)
            worker = threading.Thread(target=server.serve_forever, daemon=True)
            worker.start()
            try:
                with urllib.request.urlopen(url) as reply:
                    body = reply.read().decode()
                    self.assertIn("Generate Excel graphs", body)
                    self.assertNotIn("BD342", body)
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(urllib.request.Request(url + "generate", data=b"{}",
                        headers={"Origin": "https://untrusted.example", "Content-Type": "application/json"}))
                self.assertEqual(error.exception.code, 403)
                with self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(url + "download/missing/traces.xlsx")
                self.assertEqual(error.exception.code, 404)
                spec = fixture(Path(folder))
                payload = json.dumps({"config": {"schema_version": 1, "recordings": [spec]},
                                      "filename": "synthetic.csv",
                                      "data": (Path(folder) / "synthetic.csv").read_text()}).encode()
                with urllib.request.urlopen(urllib.request.Request(url + "generate", data=payload,
                                            headers={"Content-Type": "application/json"})) as reply:
                    self.assertEqual(reply.status, 202)
                    job_id = json.load(reply)["job_id"]
                deadline = time.monotonic() + 45
                while time.monotonic() < deadline:
                    with urllib.request.urlopen(url + "status/" + job_id) as reply:
                        job = json.load(reply)
                    if job["status"] != "running":
                        break
                    time.sleep(.1)
                self.assertEqual(job["status"], "complete", job)
                with urllib.request.urlopen(url + "download/" + job_id + "/traces.xlsx") as reply:
                    self.assertIn("attachment", reply.headers["Content-Disposition"])
                    self.assertTrue(reply.read().startswith(b"PK"))
            finally:
                server.shutdown()
                server.server_close()
                worker.join()

if __name__ == "__main__":
    unittest.main()
