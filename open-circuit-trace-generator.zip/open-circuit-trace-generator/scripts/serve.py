#!/usr/bin/env python3
"""Loopback-only local form for the deterministic trace generator."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import argparse
import datetime
import json
import mimetypes
import secrets
import threading
import urllib.parse
import webbrowser
from run import generate, SKILL

def make_server(output_root, port=0):
    output_root=Path(output_root).expanduser().resolve()
    output_root.mkdir(parents=True,exist_ok=True)
    prefix='/'+secrets.token_urlsafe(24)+'/'
    jobs={}
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def reply(self,status,body,mime='application/json',attachment=None):
            if isinstance(body,dict):body=json.dumps(body).encode()
            elif isinstance(body,str):body=body.encode()
            self.send_response(status)
            self.send_header('Content-Type',mime)
            self.send_header('Content-Length',str(len(body)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            if attachment:self.send_header('Content-Disposition','attachment; filename="'+attachment+'"')
            self.end_headers();self.wfile.write(body)
        def route(self):
            expected_host='127.0.0.1:'+str(self.server.server_address[1])
            if self.headers.get('Host')!=expected_host:return None
            path=urllib.parse.urlsplit(self.path).path
            if not path.startswith(prefix):return None
            return path[len(prefix):]
        def do_GET(self):
            route=self.route()
            if route is None:return self.reply(404,{'error':'Not found'})
            if route=='':return self.reply(200,(SKILL/'assets/form.html').read_bytes(),'text/html; charset=utf-8')
            if route.startswith('status/'):
                job=jobs.get(route.split('/')[-1])
                if job is None:return self.reply(404,{'error':'Unknown run'})
                return self.reply(200,{k:v for k,v in job.items() if k!='folder'})
            if route.startswith('download/'):
                parts=route.split('/')
                if len(parts)!=3:return self.reply(404,{'error':'Not found'})
                _,job_id,name=parts;job=jobs.get(job_id)
                if not job or job['status']!='complete' or name not in job['files']:
                    return self.reply(404,{'error':'File not ready'})
                p=Path(job['folder'])/name
                return self.reply(200,p.read_bytes(),mimetypes.guess_type(name)[0] or 'application/octet-stream',name)
            return self.reply(404,{'error':'Not found'})
        def do_POST(self):
            if self.route()!='generate':return self.reply(404,{'error':'Not found'})
            origin='http://127.0.0.1:'+str(self.server.server_address[1])
            if self.headers.get('Origin') not in (None,origin):
                return self.reply(403,{'error':'Use the local form tab.'})
            try:
                size=int(self.headers.get('Content-Length','0'))
                if not 0<size<=50_000_000:raise ValueError('The upload must be smaller than 50 MB.')
                request=json.loads(self.rfile.read(size))
                config=request['config']
                if len(config.get('recordings',[]))!=1:raise ValueError('This form accepts one recording at a time; the command tool supports batches.')
                filename=request.get('filename','')
                suffix=Path(filename).suffix.lower()
                if suffix not in ('.csv','.tsv','.txt'):raise ValueError('Select a numeric CSV, TSV or TXT export.')
                text=request['data']
                if not isinstance(text,str):raise ValueError('No numeric data file was supplied.')
                job_id=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+secrets.token_hex(3)
                folder=output_root/job_id
                folder.mkdir()
                upload=folder/Path(filename).name
                upload.write_text(text,encoding='utf-8')
                config['recordings'][0]['file']=upload.name
                settings=folder/'submitted_settings.json'
                settings.write_text(json.dumps(config,indent=2))
                result=folder/'results'
                jobs[job_id]={'status':'running','message':'Checking data and generating your Excel charts…','folder':str(result)}
                def work():
                    try:
                        generate(settings,result)
                        report=json.loads((result/'verification.json').read_text())
                        warnings=[w for r in report['runs'] for w in r['warnings']]
                        files=['traces.xlsx','Results.md','experiment.json','verification.json']
                        files += sorted(p.name for p in result.glob('*.png') if '_table' not in p.name)
                        jobs[job_id].update(status='complete',message='Charts generated and calculation checks passed.',
                                            warnings=warnings,files=files,output_folder=str(result))
                    except Exception as exc:
                        detail=str(exc)
                        log=result/'run.log'
                        if log.exists():detail+='\n'+log.read_text()[-1800:]
                        jobs[job_id].update(status='failed',message=detail)
                threading.Thread(target=work,daemon=True).start()
                return self.reply(202,{'job_id':job_id})
            except (ValueError,KeyError,TypeError,OSError) as exc:
                return self.reply(400,{'error':str(exc)})
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    return server,'http://127.0.0.1:'+str(server.server_address[1])+prefix

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root',required=True)
    parser.add_argument('--port',type=int,default=0)
    parser.add_argument('--no-open',action='store_true')
    args=parser.parse_args()
    server,url=make_server(args.output_root,args.port)
    print('Trace Generator runs only on your computer. No AI or API connection.',flush=True)
    print('Open: '+url,flush=True)
    print('Keep this window open while generating. Press Control-C to stop.',flush=True)
    if not args.no_open:webbrowser.open(url)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
