"""Portable XLSX exporter. Analysis is unchanged; finalization verifies every cache."""
from pathlib import Path
import json
import math
import sys
import xlsxwriter
from xlsxwriter.utility import xl_col_to_name as col

NAVY = "#22374B"
COLORS = ["#111111", "#C62828", "#2563EB", "#15803D"]

def ref(sheet, column, start, end):
    return "'" + sheet.name + "'!$" + col(column) + "$" + str(start) + ":$" + col(column) + "$" + str(end)

def label(text):
    text = str(text)
    return "'" + text if text.startswith("=") else text

def build(out):
    data = json.loads((out / "analysis.json").read_text(encoding="utf-8"))
    runs, specs = data["runs"], []
    w = xlsxwriter.Workbook(out / "traces.xlsx", {"strings_to_formulas": False, "strings_to_urls": False})
    w.set_properties({"title": str(data["title"]), "author": "Open-Circuit Trace Generator"})
    w.set_calc_mode("auto")
    base = {"font_name": "Arial", "font_size": 10}
    normal = w.add_format(base)
    title = w.add_format({**base, "font_size": 15, "bold": True})
    heading = w.add_format({**base, "bold": True, "font_color": "white", "bg_color": NAVY,
                            "text_wrap": True, "valign": "vcenter"})
    numeric = w.add_format({**base, "num_format": "0.0000"})
    editable = w.add_format({**base, "bg_color": "#FFF2CC", "num_format": "0.0000"})
    wrapped = w.add_format({**base, "text_wrap": True, "valign": "top"})
    figures = {(r["run"], kind): w.add_worksheet(r["run"] + "_" + kind)
               for r in runs for kind in ("Voltage", "Ieq", "TEER")}
    settings = w.add_worksheet("Settings and method")
    sheets = {r["run"]: (w.add_worksheet(r["run"] + "_Voltage_Raw"),
                          w.add_worksheet(r["run"] + "_Ieq_Calc"),
                          w.add_worksheet(r["run"] + "_TEER_Calc")) for r in runs}
    for sheet in w.worksheets():
        sheet.hide_gridlines(2)
        sheet.set_column("A:AG", 18, normal)
    settings.set_column("I:I", 40)
    settings.merge_range("A2:I2", data["title"], title)
    settings.merge_range("A3:I3", "Yellow cells: editable calibration. Rerun to change pulse detection or fixed chart axes.", wrapped)
    settings.write_row("A5", ["Recording", "Area (cm²)", "Current low (µA)", "Current high (µA)",
                              "ΔIpp (µA)", "Voltage unit", "To mV factor", "Interval (s)", "Groups"], heading)
    settings.set_row(4, 36)
    for i, run in enumerate(runs):
        row = i + 5
        settings.write_row(row, 0, [run["run"], run["area"], run["current_low"], run["current_high"],
                                   None, run["unit"], run["unit_factor"], run["sample_interval"], "; ".join(run["groups"])])
        for c, value in enumerate((run["area"], run["current_low"], run["current_high"]), 1):
            settings.write_number(row, c, value, editable)
        settings.write_formula(row, 4, f"=D{row+1}-C{row+1}", numeric, run["current_step"])
        settings.data_validation(row, 1, row, 1, {"validate": "decimal", "criteria": ">", "value": 0})
        settings.data_validation(row, 2, row, 2, {"validate": "decimal", "criteria": "<", "value": 0})
        settings.data_validation(row, 3, row, 3, {"validate": "decimal", "criteria": ">", "value": 0})
    notes = [
        "All selected raw values and their original time origin are retained. Original exports are copied to inputs/.",
        "V input remains in V on source sheets; pulse measurement formulas convert V to mV.",
        "R × area (Ω·cm²) = 1000 × ΔVpp (mV) × area (cm²) / ΔIpp (µA), before additional blank correction.",
        "Ieq magnitude (µA/cm²) = abs(baseline mV) / ΔVpp (mV) × ΔIpp (µA) / area (cm²).",
        "ΔIpp = current high − current low. This method requires low < 0 < high (biphasic pulses).",
        "Flagged finite measurements stay included. Invalid pulse heights leave gaps; group means require all samples.",
        "Incomplete pulse/baseline windows are excluded from Ieq and TEER; all raw voltage rows remain.",
        "Group curves are arithmetic means. No statistical tests or biological conclusions are generated.",
        "No smoothing or downsampling. Axis limits are fixed; rerun after changing calibration for final figures.",
        "Annotations use supplied original times. Review pulse-window figures and all QC flags before using results.",
        "Native chart formulas update in Excel. Initial cached results are independently verified against source values.",
        "This research-use tool is not a clinical diagnostic system. Example data are synthetic.",
        "Analysis version: " + data["version"] + ". Public exporter: 1.1.0 (Python/XlsxWriter)."
    ]
    for row, note in enumerate(notes, 16):
        settings.merge_range(row, 0, row, 8, note, wrapped)
        settings.set_row(row, 30)
    settings.write_row("A32", ["Recording", "Annotation", "Time (s)"], heading)
    eventrow = 32
    for run in runs:
        for text, time in run["events"]:
            settings.write_row(eventrow, 0, [run["run"], text, time])
            eventrow += 1
    teer_notes = [
        "TEER (Ω·cm²) = (pulse resistance in Ω − remaining blank in Ω) × area in cm².",
        "Only subtract uncompensated resistance. Confirmed compensation uses 0 Ω; unknown calibration stays blank.",
        "Blank correction affects TEER only. Ieq retains its original pulse-resistance calculation.",
        "Nonpositive TEER is retained and flagged. Group means require every sample at a pulse.",
        "Method: WPI EndOhm manual, Appendix A: https://www.wpiinc.com/media/wysiwyg/pdf/EndOhm_IMs.pdf"
    ]
    for row, note in enumerate(teer_notes, eventrow + 1):
        settings.merge_range(row, 0, row, 8, note, wrapped)
        settings.set_row(row, 30)
    blankrow = eventrow + len(teer_notes) + 3
    settings.write_row(blankrow, 0, ["Recording", "Sample", "Remaining blank (Ω)", "TEER calibration"], heading)
    settings.set_row(blankrow, 36)
    blank_cells = {}
    for run in runs:
        for c, channel in enumerate(run["channels"]):
            blankrow += 1
            value = run["teer"]["blank_ohm"][c]
            settings.write_row(blankrow, 0, [run["run"], channel["label"]])
            if value is None:
                settings.write_blank(blankrow, 2, None, editable)
            else:
                settings.write_number(blankrow, 2, value, editable)
            cell = f"C{blankrow+1}"
            settings.write_formula(blankrow, 3,
                f'=IF(COUNT({cell})=0,"Pending blank calibration",IF({cell}<0,"Invalid negative blank","Remaining blank supplied"))',
                wrapped, "Pending blank calibration" if value is None else "Remaining blank supplied")
            settings.set_row(blankrow, 32)
            settings.data_validation(blankrow, 2, blankrow, 2, {"validate": "decimal", "criteria": ">=", "value": 0})
            blank_cells[(run["run"], c)] = f"'Settings and method'!$C${blankrow+1}"
    help_row = max(70, blankrow + 4)  # one-based row for chart helpers in L:M

    for ri, run in enumerate(runs):
        raw, calc, teer = sheets[run["run"]]
        nc, pc, n = len(run["channels"]), len(run["pulses"]), len(run["rows"])
        sr = ri + 6
        area, step, factor, low, high = [f"'Settings and method'!${c}${sr}" for c in ("B", "E", "G", "C", "D")]
        calibration = f"AND({area}>0,{low}<0,{high}>0)"
        groups = [[i for i, c in enumerate(run["channels"]) if c["group"] == g] for g in run["groups"]]
        mean_start, plot_mean = nc + 2, 16 + nc
        raw.write("A1", run["source"])
        raw.write("A2", f"{n} samples; original voltage units {run['unit']}; original time origin retained.")
        raw.write("A3", "SHA-256: " + run["sha256"])
        raw.write("A4", "Original numeric values, unchanged. Group means at right are derived.")
        raw.write_row("A6", ["Time (s)"] + [c["label"] + " (" + run["unit"] + ")" for c in run["channels"]], heading)
        raw.write_row(5, mean_start, [g + " mean (" + run["unit"] + ")" for g in run["groups"]], heading)
        raw.set_row(5, 36)
        raw_fmt = w.add_format({**base, "num_format": "0.000000" if run["unit"] == "V" else "0.0000"})
        for row, values in enumerate(run["rows"], 6):
            raw.write_row(row, 0, values, raw_fmt)
            for gi, indices in enumerate(groups):
                cells = ",".join(col(i+1) + str(row+1) for i in indices)
                mean = sum(values[i+1] for i in indices) / len(indices)
                raw.write_formula(row, mean_start+gi, f"=AVERAGE({cells})", raw_fmt, mean)
        raw.freeze_panes(6, 1)
        calc.set_column("N:N", 62)
        calc.write("A1", f"{run['run']}: {pc} complete pulse cycles; {nc} samples. Ieq is a magnitude.")
        calc.write("A2", f"Baseline: {run['analysis']['baseline_start_before_s']} to {run['analysis']['baseline_end_before_s']} s before onset; pulse window: {run['analysis']['pulse_window_s']} s.")
        calc.write("A3", run["detector"] + "; settings in experiment.json; reference " + run["channels"][run["analysis"]["reference_channel"]]["label"])
        calc.write("A4", " ".join(run["warnings"]) or "No automatic QC flags. Review pulse windows.")
        calc.write("A5", "Flagged finite measurements remain included. Invalid pulse heights leave gaps.")
        calc.write_row("A6", ["Cycle", "Time (s)", "Sample", "Baseline start (s)", "Baseline end (s)", "Pulse start (s)",
                              "Pulse end (s)", "Baseline (mV)", "Min (mV)", "Max (mV)", "ΔVpp (mV)",
                              "R × area (Ω·cm²)", "Ieq (µA/cm²)", "QC note"], heading)
        calc.write("P4", "Chart helpers: intentional #N/A means an omitted measurement, not zero.")
        calc.write_row("P6", ["Time (s)"] + [c["label"] for c in run["channels"]] + [g + " mean" for g in run["groups"]], heading)
        calc.set_row(5, 36)
        calc.freeze_panes(6, 3)
        for p, pulse in enumerate(run["pulses"]):
            for c, channel in enumerate(run["channels"]):
                r = 7 + p*nc + c
                src = "'" + raw.name + "'!" + col(c+1)
                valid = f"AND({calibration},K{r}>{run['analysis']['minimum_delta_mV']})"
                calc.write_row(r-1, 0, [p+1, pulse["time"], channel["label"],
                    *[run["rows"][pulse[key]][0] for key in ("baseline_start", "baseline_end", "start", "end")]], numeric)
                formulas = [f"=AVERAGE({src}{pulse['baseline_start']+7}:{col(c+1)}{pulse['baseline_end']+7})*{factor}",
                            f"=MIN({src}{pulse['start']+7}:{col(c+1)}{pulse['end']+7})*{factor}",
                            f"=MAX({src}{pulse['start']+7}:{col(c+1)}{pulse['end']+7})*{factor}", f"=J{r}-I{r}",
                            f'=IF({valid},1000*K{r}*{area}/{step},"")',
                            f'=IF({valid},ABS(H{r})/K{r}*{step}/{area},"")']
                cached = [pulse["base"][c], pulse["low"][c], pulse["high"][c], pulse["dv"][c],
                          1000*pulse["dv"][c]*run["area"]/run["current_step"] if pulse["ieq"][c] is not None else "",
                          pulse["ieq"][c] if pulse["ieq"][c] is not None else ""]
                for column, (formula, value) in enumerate(zip(formulas, cached), 7):
                    calc.write_formula(r-1, column, formula, numeric, value)
                calc.write(r-1, 13, pulse["flags"][c])
            r, b = 7+p, 7+p*nc
            calc.write_formula(r-1, 15, f"=B{b}", numeric, pulse["time"])
            for c, value in enumerate(pulse["ieq"]):
                calc.write_formula(r-1, 16+c, f"=IF(ISNUMBER(M{b+c}),M{b+c},NA())", numeric,
                                   value if value is not None else "#N/A")
            for gi, indices in enumerate(groups):
                refs = ",".join(col(16+i)+str(r) for i in indices)
                values = [pulse["ieq"][i] for i in indices]
                mean = sum(values)/len(values) if all(v is not None for v in values) else "#N/A"
                calc.write_formula(r-1, plot_mean+gi, f"=IF(COUNT({refs})={len(indices)},AVERAGE({refs}),NA())", numeric, mean)

        teer.set_column("C:C", 26)
        teer.set_column("D:F", 22)
        teer.set_column("G:G", 60)
        teer.write("A1", run["run"] + " — pulse resistance and TEER")
        teer.write("A2", "TEER = (pulse resistance − remaining blank) × area. Yellow blank inputs are on Settings and method.")
        teer.write("A3", "Unknown blank stays empty. Nonpositive values remain for review; invalid pulses produce gaps.")
        teer.write_row("A6", ["Cycle", "Time (s)", "Sample", "Pulse R (Ω)", "Remaining blank (Ω)", "TEER (Ω·cm²)", "TEER note"], heading)
        teer.set_row(5, 36)
        teer.freeze_panes(6, 3)
        teer.write("J4", "Chart helpers: #N/A marks unavailable values. Group means require every sample.")
        teer.write_row("J6", ["Time (s)"] + [c["label"] for c in run["channels"]] + [g + " mean" for g in run["groups"]], heading)
        for p, pulse in enumerate(run["pulses"]):
            for c, channel in enumerate(run["channels"]):
                r = 7+p*nc+c
                source = "'" + calc.name + "'!"
                blank = blank_cells[(run["run"], c)]
                resistance, remaining, value = pulse["resistance_ohm"][c], run["teer"]["blank_ohm"][c], pulse["teer"][c]
                note = ("Invalid pulse or current/area calibration" if resistance is None else
                        "Pending blank calibration" if remaining is None else
                        "Nonpositive TEER: review blank and pulse" if value <= 0 else "")
                formulas = [f"={source}A{r}", f"={source}B{r}", f"={source}C{r}",
                    f'=IF(ISNUMBER({source}L{r}),{source}L{r}/{area},"")',
                    f'=IF(COUNT({blank})=1,{blank},"")',
                    f'=IF(AND(ISNUMBER(D{r}),ISNUMBER(E{r}),E{r}>=0),(D{r}-E{r})*{area},"")',
                    f'=IF(NOT(ISNUMBER(D{r})),"Invalid pulse or current/area calibration",IF(NOT(ISNUMBER(E{r})),"Pending blank calibration",IF(E{r}<0,"Invalid negative blank",IF(F{r}<=0,"Nonpositive TEER: review blank and pulse",""))))']
                values = [p+1, pulse["time"], channel["label"], resistance, remaining, value, note]
                for c2, (formula, cached) in enumerate(zip(formulas, values)):
                    teer.write_formula(r-1, c2, formula, wrapped if c2 == 6 else numeric,
                                       "" if cached is None else cached)
            r, b = 7+p, 7+p*nc
            teer.write_formula(r-1, 9, f"=B{b}", numeric, pulse["time"])
            for c, value in enumerate(pulse["teer"]):
                teer.write_formula(r-1, 10+c, f"=IF(ISNUMBER(F{b+c}),F{b+c},NA())", numeric,
                                   value if value is not None else "#N/A")
            for gi, indices in enumerate(groups):
                refs = ",".join(col(10+i)+str(r) for i in indices)
                values = [pulse["teer"][i] for i in indices]
                mean = sum(values)/len(values) if all(v is not None for v in values) else "#N/A"
                teer.write_formula(r-1, 10+nc+gi, f"=IF(COUNT({refs})={len(indices)},AVERAGE({refs}),NA())", numeric, mean)
        teer.conditional_format(6, 5, pc*nc+5, 5, {"type": "formula", "criteria": "=AND(ISNUMBER(F7),F7<=0)", "format": editable})

        for kind in ("Voltage", "Ieq", "TEER"):
            sheet = figures[(run["run"], kind)]
            sheet.set_column("A:AG", 5, normal)
            sheet.set_default_row(15)
            sheet.set_tab_color(NAVY if kind == "Voltage" else "#7D2A2A" if kind == "Ieq" else "#275C4C")
            sheet.write("B2", run["title"] + " — " + kind, title)
            sheet.write("B3", "; ".join(f"{g}, n = {len(indices)}" for g, indices in zip(run["groups"], groups)))
            if kind == "Voltage":
                sheet.write("B4", "Full trace; original time origin; all selected samples retained.")
            else:
                sheet.write_formula("B4", f'=IF({calibration},"Area = "&{area}&" cm²; current step = "&{step}&" µA peak-to-peak","Invalid calibration: check Settings and method.")',
                                    normal, f"Area = {run['area']} cm²; current step = {run['current_step']} µA peak-to-peak")
            if kind == "TEER":
                available = any(v is not None for p in run["pulses"] for v in p["teer"])
                unavailable = "TEER unavailable: check blank calibration and pulse measurements."
                available_note = "TEER uses remaining blank resistance. Nonpositive values require review; see TEER_Calc."
                sheet.write_formula("B5", f'=IF(COUNT(\'{teer.name}\'!F7:F{pc*nc+6})=0,"{unavailable}","{available_note}")', normal,
                                    available_note if available else unavailable)
            x = [r[0] for r in run["rows"]] if kind == "Voltage" else [p["time"] for p in run["pulses"]]
            y = [r[1:] for r in run["rows"]] if kind == "Voltage" else [p["ieq" if kind == "Ieq" else "teer"] for p in run["pulses"]]
            xmin, xmax = min(0, x[0]), max(2000, math.ceil(x[-1]/500)*500)
            limits = []
            for indices in groups:
                vals = [row[i] for row in y for i in indices if row[i] is not None]
                lo, hi = min([0]+vals), max([0]+vals)
                pad = max((hi-lo)*.12, .1/run["unit_factor"])
                if kind == "TEER":
                    hi = max([hi] + [p["resistance_ohm"][i]*run["area"] for p in run["pulses"] for i in indices if p["resistance_ohm"][i] is not None])
                    limits.append((lo*1.15, max(10, hi)*1.15))
                else:
                    limits.append((lo-pad, hi+pad) if kind == "Voltage" else (0, max(10, math.ceil(hi*1.15/10)*10)))
            for panel in range(nc+1):
                overlay = panel == nc
                g = 0 if overlay else run["groups"].index(run["channels"][panel]["group"])
                ymin, ymax = (min(v[0] for v in limits), max(v[1] for v in limits)) if overlay else limits[g]
                count = len(groups) if overlay else 1
                chart = w.add_chart({"type": "scatter", "subtype": "straight_with_markers"})
                chart.set_size({"width": 1280 if overlay else 400, "height": 400 if overlay else 300})
                caption = "Group means" if overlay else run["channels"][panel]["label"] + " (" + run["channels"][panel]["group"] + ")"
                chart.set_title({"name": label(chr(65+panel) + "  " + caption), "name_font": {"name": "Arial", "size": 13, "bold": True}})
                chart.set_chartarea({"fill": {"color": "white"}, "border": {"color": "black"}})
                axis = {"major_gridlines": {"visible": False}, "minor_gridlines": {"visible": False},
                        "major_tick_mark": "outside", "minor_tick_mark": "none", "line": {"color": "black"},
                        "num_font": {"name": "Arial", "size": 11}, "name_font": {"name": "Arial", "size": 12, "bold": True}}
                chart.set_x_axis({**axis, "name": "Time (s)", "min": xmin, "max": xmax, "major_unit": 500, "num_format": "0", "label_position": "low"})
                chart.set_y_axis({**axis, "name": "Vte ("+run["unit"]+")" if kind == "Voltage" else "Ieq (µA/cm²)" if kind == "Ieq" else "TEER (Ω·cm²)",
                                  "min": ymin, "max": ymax, "num_format": ("0.000" if run["unit"] == "V" else "0.0") if kind == "Voltage" else "0"})
                chart.set_legend({"position": "right", "font": {"name": "Arial", "size": 10}} if overlay else {"none": True})
                chart.show_blanks_as("gap")
                bindings = []
                source = raw if kind == "Voltage" else calc if kind == "Ieq" else teer
                end, xc = (n+6, 0) if kind == "Voltage" else (pc+6, 15 if kind == "Ieq" else 9)
                for k in range(count):
                    c = ((mean_start+k if overlay else panel+1) if kind == "Voltage" else
                         (plot_mean+k if overlay else 16+panel) if kind == "Ieq" else
                         (10+nc+k if overlay else 10+panel))
                    binding = {"x": ref(source, xc, 7, end), "y": ref(source, c, 7, end)}
                    bindings.append(binding)
                    marker = {"type": "none"} if kind == "Voltage" or overlay else {"type": "square" if g == 0 else "circle", "size": 4}
                    chart.add_series({"name": label(run["groups"][k] if overlay else run["channels"][panel]["label"]),
                        "categories": "="+binding["x"], "values": "="+binding["y"], "marker": marker,
                        "line": {"color": COLORS[k] if overlay else "#111111", "width": 1 if kind == "Voltage" else 1.5}})
                helpers = ([("Zero", [xmin, xmax], [0, 0], True)] if kind == "Voltage" else [])
                helpers += [(text, [time, time], [ymin, ymax-(ymax-ymin)*.11], False) for text, time in run["events"]]
                for text, xv, yv, zero in helpers:
                    settings.write_row(help_row-1, 11, [xv[0], yv[0]])
                    settings.write_row(help_row, 11, [xv[1], yv[1]])
                    binding = {"x": ref(settings, 11, help_row, help_row+1), "y": ref(settings, 12, help_row, help_row+1)}
                    bindings.append(binding)
                    options = {"name": label(text), "categories": "="+binding["x"], "values": "="+binding["y"],
                               "marker": {"type": "none"}, "line": {"color": "black" if zero else "#9CA3AF", "width": 1 if zero else .6, "dash_type": "dash"}}
                    if not zero:
                        options["data_labels"] = {"position": "above", "custom": [{"delete": True}, {"value": label(text)}], "font": {"name": "Arial", "size": 10}}
                    chart.add_series(options)
                    help_row += 2
                row = 7 + math.ceil(nc/3)*16 if overlay else 6 + (panel//3)*16
                column = 1 if overlay else 1+(panel%3)*10
                sheet.insert_chart(row, column, chart)
                specs.append({"sheet": sheet.name, "type": kind, "panel": panel, "overlay": overlay,
                              "seriesCount": count, "ymin": ymin, "ymax": ymax, "xmin": xmin,
                              "events": len(run["events"]), "bindings": bindings})
    w.close()
    (out / "chart_specs.json").write_text(json.dumps(specs), encoding="utf-8")
    print(f"Built {len(specs)} editable Excel charts with portable Python dependencies.")

if __name__ == "__main__":
    build(Path(sys.argv[1]).resolve())
