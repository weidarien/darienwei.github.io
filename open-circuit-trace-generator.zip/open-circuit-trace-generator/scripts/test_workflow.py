"""Small behavioral checks for calibration, units, gaps and input rejection."""
from pathlib import Path
import copy
import csv
import json
import sys
import tempfile
import unittest

from trace_core import analyze_recording

def fixture(folder):
    p=Path(folder)/'synthetic.csv'
    rows=[]
    for i in range(160):
        values=[-.002,-.003,-.001,-.004]
        phase=(i-12)%40
        if phase in (0,1):
            values[0]-=.0005;values[1]-=.0005;values[2]-=.00025
        if phase in (2,3):
            values[0]+=.0005;values[1]+=.0005;values[2]+=.00025
        rows.append([10+i*.25,*values])
    with p.open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['Seconds','A','B','C','D']);w.writerows(rows)
    spec={'id':'UNIT_TEST','title':'Synthetic unit conversion and missing pulse test','file':p.name,
          'time_column':'Seconds','voltage_units':'V','area_cm2':.5,'current_low_uA':-2,'current_high_uA':2,
          'channels':[{'column':c,'label':'Sample '+c,'group':'Control' if i<2 else 'Treatment'} for i,c in enumerate('ABCD')],
          'events':[{'label':'Test drug','time_s':30}]}
    return spec

class AnalysisChecks(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.folder=Path(self.tmp.name);self.spec=fixture(self.folder)
    def tearDown(self):self.tmp.cleanup()
    def test_voltage_units_and_current_scale(self):
        r=analyze_recording(self.spec,self.folder)
        self.assertEqual(len(r['pulses']),4)
        self.assertEqual(r['rows'][0][0],10)
        self.assertEqual(r['rows'][0][1],-.002)
        self.assertAlmostEqual(r['pulses'][0]['base'][0],-2)
        self.assertAlmostEqual(r['pulses'][0]['dv'][0],1)
        self.assertAlmostEqual(r['pulses'][0]['ieq'][0],16)
        self.assertIsNone(r['pulses'][0]['ieq'][3])
        self.assertIn('Invalid pulse height',r['pulses'][0]['flags'][3])
        changed=copy.deepcopy(self.spec);changed['area_cm2']=1
        self.assertAlmostEqual(analyze_recording(changed,self.folder)['pulses'][0]['ieq'][0],8)
        changed=copy.deepcopy(self.spec);changed.update(current_low_uA=-1,current_high_uA=1)
        self.assertAlmostEqual(analyze_recording(changed,self.folder)['pulses'][0]['ieq'][0],8)
    def test_manual_times_retain_recording_origin(self):
        spec=copy.deepcopy(self.spec);spec['pulse_onsets_s']=[13,23,33,43]
        r=analyze_recording(spec,self.folder)
        self.assertEqual([p['time'] for p in r['pulses']],[13,23,33,43])
    def test_bad_calibration_and_metadata_stop(self):
        for edit in [{'area_cm2':0},{'current_low_uA':1},{'voltage_units':'µV'},
                     {'events':[{'label':'FSK','time_s':0}]},{'time_column':'missing'},
                     {'analysis':{'pulse_window_s':2.2}}]:
            with self.subTest(edit=edit),self.assertRaises(ValueError):
                analyze_recording({**self.spec,**edit},self.folder)
    def test_gaps_and_nonfinite_stop(self):
        p=self.folder/'synthetic.csv';original=p.read_text()
        p.write_text(original.replace('10.25,','10.5,',1))
        with self.assertRaises(ValueError):analyze_recording(self.spec,self.folder)
        p.write_text(original.replace('-0.002,','nan,',1))
        with self.assertRaises(ValueError):analyze_recording(self.spec,self.folder)
    def test_duplicate_channel_stops(self):
        spec=copy.deepcopy(self.spec);spec['channels'][1]['column']='A'
        with self.assertRaises(ValueError):analyze_recording(spec,self.folder)
    def test_teer_unknown_is_not_zero(self):
        r=analyze_recording(self.spec,self.folder)
        self.assertEqual(r['teer']['mode'],'pending')
        self.assertAlmostEqual(r['pulses'][0]['resistance_ohm'][0],250)
        self.assertTrue(all(x is None for p in r['pulses'] for x in p['teer']))
        self.assertTrue(any('TEER pending' in w for w in r['warnings']))
    def test_teer_blank_and_per_channel_override(self):
        r=analyze_recording({**self.spec,'teer':{'mode':'subtract_blank','blank_ohm':50,'blank_ohm_by_channel':{'B':100,'C':0}}},self.folder)
        self.assertAlmostEqual(r['pulses'][0]['teer'][0],100)
        self.assertAlmostEqual(r['pulses'][0]['teer'][1],75)
        self.assertAlmostEqual(r['pulses'][0]['teer'][2],62.5)
        self.assertIsNone(r['pulses'][0]['teer'][3])
        self.assertAlmostEqual(r['pulses'][0]['ieq'][0],16)
    def test_teer_compensated_and_scaling(self):
        spec={**self.spec,'teer':{'mode':'already_compensated'}}
        self.assertAlmostEqual(analyze_recording(spec,self.folder)['pulses'][0]['teer'][0],125)
        self.assertAlmostEqual(analyze_recording({**spec,'area_cm2':1},self.folder)['pulses'][0]['teer'][0],250)
        self.assertAlmostEqual(analyze_recording({**spec,'current_low_uA':-1,'current_high_uA':1},self.folder)['pulses'][0]['teer'][0],250)
    def test_teer_units_are_equivalent(self):
        spec={**self.spec,'teer':{'mode':'already_compensated'}}
        volts=analyze_recording(spec,self.folder)
        p=self.folder/'synthetic.csv'
        with p.open() as f:rows=list(csv.reader(f))
        for row in rows[1:]:
            for i in range(1,len(row)):row[i]=float(row[i])*1000
        with p.open('w',newline='') as f:csv.writer(f).writerows(rows)
        millivolts=analyze_recording({**spec,'voltage_units':'mV'},self.folder)
        for a,b in zip(volts['pulses'],millivolts['pulses']):self.assertEqual(a['teer'],b['teer'])
    def test_teer_bad_calibration_and_double_correction_stop(self):
        for teer in [{'mode':'subtract_blank'}, {'mode':'subtract_blank','blank_ohm':-1},
                     {'mode':'subtract_blank','blank_ohm':float('nan')},
                     {'mode':'subtract_blank','blank_ohm':True},
                     {'mode':'subtract_blank','blank_ohm':0,'blank_ohm_by_channel':{'Typo':2}},
                     {'mode':'already_compensated','blank_ohm':10}, {'mode':'pending','blank_ohm':0},
                     {'mode':'unknown'}]:
            with self.subTest(teer=teer),self.assertRaises(ValueError):analyze_recording({**self.spec,'teer':teer},self.folder)
    def test_nonpositive_teer_retained_and_flagged(self):
        r=analyze_recording({**self.spec,'teer':{'mode':'subtract_blank','blank_ohm':300}},self.folder)
        self.assertAlmostEqual(r['pulses'][0]['teer'][0],-25)
        self.assertTrue(any('nonpositive TEER' in w for w in r['warnings']))

if __name__=='__main__':unittest.main()
