#!/usr/bin/env python3
"""Generate and independently verify native Excel charts, without Codex or Node."""
from pathlib import Path
import argparse
import datetime
import json
import shutil
import subprocess
import sys
from trace_core import prepare, plots

SKILL = Path(__file__).resolve().parent.parent

def generate(config_path, out):
    config_path = Path(config_path).expanduser().resolve()
    config = json.loads(config_path.read_text(encoding="utf-8"))
    data = prepare(config, config_path.parent)
    out = Path(out).expanduser().resolve()
    if out.exists() and any(out.iterdir()):
        raise ValueError("Output folder is not empty. Choose a new folder; existing results are never overwritten.")
    out.mkdir(parents=True, exist_ok=True)
    print("Input validated. Building " + str(len(data["runs"])) + " recording(s).", flush=True)
    try:
        inputs = out / "inputs"
        inputs.mkdir()
        reproducible = json.loads(json.dumps(config))
        for i, run in enumerate(data["runs"]):
            name = run["run"] + Path(run["source"]).suffix.lower()
            shutil.copy2(run["source_path"], inputs / name)
            reproducible["recordings"][i]["file"] = "inputs/" + name
        (out / "experiment.json").write_text(json.dumps(reproducible, indent=2), encoding="utf-8")
        (out / "analysis.json").write_text(json.dumps(data, allow_nan=False), encoding="utf-8")
        (out / "status.json").write_text(json.dumps({"status": "building"}), encoding="utf-8")
        with (out / "run.log").open("w", encoding="utf-8") as log:
            for script in ("build_workbook.py", "finalize.py"):
                subprocess.run([sys.executable, str(SKILL / "scripts" / script), str(out)],
                               check=True, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
        print("Saved values and native charts checked. Rendering review figures.", flush=True)
        plots(data, out)
        report = json.loads((out / "verification.json").read_text(encoding="utf-8"))
        summary = ["# Trace generation complete", "", "Workbook: traces.xlsx. Original exports: inputs/.",
                   "Reusable settings: experiment.json. Native editable charts and formula cells are included.",
                   "Ieq is a magnitude, not signed current. Review QC and pulse-window figures before use.",
                   "Formulas include verified initial cached values; Excel recalculates them when opened.", ""]
        for run, check in zip(data["runs"], report["runs"]):
            summary += ["## " + run["run"], "", f"{check['raw_rows_verified']} source rows; "
                        f"{check['pulse_cycles']} complete pulses; {check['Ieq_values_verified']} verified Ieq values.",
                        f"Area {run['area']} cm²; current {run['current_low']} to {run['current_high']} µA.", ""]
            summary += ["- " + warning for warning in run["warnings"]] or ["No automatic QC flags."]
            summary.append("")
        (out / "Results.md").write_text("\n".join(summary), encoding="utf-8")
        (out / "status.json").write_text(json.dumps({"status": "complete", "workbook": "traces.xlsx"}), encoding="utf-8")
        print("COMPLETE: " + str(out / "traces.xlsx"), flush=True)
        return out
    except Exception as exc:
        (out / "status.json").write_text(json.dumps({"status": "failed", "error": str(exc)}), encoding="utf-8")
        if (out / "traces.xlsx").exists():
            (out / "traces.xlsx").rename(out / "unverified-traces.xlsx")
        raise

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--out", help="New or empty output folder")
    parser.add_argument("--check-only", action="store_true")
    args = parser.parse_args()
    try:
        config_path = Path(args.config).expanduser().resolve()
        if args.check_only:
            data = prepare(json.loads(config_path.read_text(encoding="utf-8")), config_path.parent)
            print(json.dumps([{"id": r["run"], "rows": len(r["rows"]), "pulses": len(r["pulses"]),
                               "warnings": r["warnings"]} for r in data["runs"]], indent=2))
        else:
            out = args.out or config_path.parent / ("trace_results_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
            generate(config_path, out)
    except Exception as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
