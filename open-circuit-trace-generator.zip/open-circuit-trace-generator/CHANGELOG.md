# Changes for the website download

## 1.1.0 — 2026-10-29

- Added individual and group TEER charts, formula-based TEER calculations and independent saved-value verification.
- Added pending, already-compensated and subtract-blank modes, with common and per-channel blanks. Confirmed matching dummy-membrane calibration uses zero additional subtraction; unknown calibration remains pending.
- Retained nonpositive results with flags and incomplete-group chart gaps. Ieq calculations remain unchanged.
- Added a reusable public skill, installation guidance, a synthetic TEER example and calibration/export tests.
- Public download contains synthetic data and generic settings. Personal recordings and calibration history are excluded.

## 1.0.0 — 2026-10-23

This is a separate shareable edition. The original ZIP, installed skill and research files were not edited.

### Added

- Actual analysis, plotting, workbook-export, verification and local-server source code.
- Package-relative launchers, a Python dependency list, installation instructions and tests.
- A new deterministic synthetic CSV and example settings; no original research data were used to create them.
- A standard Python/XlsxWriter workbook exporter with native editable charts, formulas and independently checked initial values.

### Removed from the shareable copy

- BD342 recordings, generated results, validation screenshots, logs and analysis dumps.
- Finder metadata (`.DS_Store`, `__MACOSX`), caches and machine-specific environment files.
- Dependencies on a preinstalled personal skill folder, bundled Node.js and the private spreadsheet runtime.

### Preserved

- The original analysis and pulse-detection implementation in `trace_core.py`.
- Calibration equations, V-to-mV conversion, source values and time origin.
- QC flags, omitted invalid measurements, strict complete-group means, plots and chart finalization.

### Important differences

- Visitors must install Python and the listed dependencies once; the ZIP is not a self-contained executable.
- The form defaults now describe the synthetic example, not a particular experiment.
- Excel output is created by XlsxWriter, so fonts/layout details may differ slightly. All initial calculated values are checked against original numeric input; Excel recalculates editable formulas on opening.
- Only macOS has been exercised for this release. Windows/Linux instructions are not a claim of platform testing.
