# Changes for the website download

## 1.0.0 — 2026-10-23

This is a separate shareable edition. The original ZIP, installed skill and research files were not edited.

### Added

- Actual analysis, plotting, workbook-export, verification and local-server source code.
- Package-relative launchers, a Python dependency list, installation instructions and tests.
- A new deterministic synthetic CSV and example settings; no original research data were used to create them.
- A standard Python/XlsxWriter workbook exporter with native editable charts, formulas and independently checked initial values.

### Removed from the shareable copy

- BD342 recordings, generated results, validation screenshots, logs and analysis dumps.
- Finder metadata (`.DS_Store`, `__MACOSX`), caches and machine-specific environment files.
- Dependencies on a preinstalled personal skill folder, bundled Node.js and the private spreadsheet runtime.

### Preserved

- The original analysis and pulse-detection implementation in `trace_core.py`.
- Calibration equations, V-to-mV conversion, source values and time origin.
- QC flags, omitted invalid measurements, strict complete-group means, plots and chart finalization.

### Important differences

- Visitors must install Python and the listed dependencies once; the ZIP is not a self-contained executable.
- The form defaults now describe the synthetic example, not a particular experiment.
- Excel output is created by XlsxWriter, so fonts/layout details may differ slightly. All initial calculated values are checked against original numeric input; Excel recalculates editable formulas on opening.
- Only macOS has been exercised for this release. Windows/Linux instructions are not a claim of platform testing.
