# Input format and method settings

The local form accepts one recording per run. JSON configuration supports 1–8 recordings in one workbook, 1–12 channels per recording, and 1–4 groups. Recordings can have different calibration and channel assignments.

CSV, TSV or TXT files must use UTF-8, a unique header row and finite numeric values. Comma, tab and semicolon delimiters are supported. Decimal separators must be periods. Time is seconds, strictly increasing and uniformly sampled. Extra unselected columns remain in the retained original file. Empty selected values, missing timepoints and duplicates stop the run instead of being repaired silently.

Example data:

    Time_s,Ch3,Ch4,Ch5,Ch6,Ch7,Ch8
    0,-0.4219,-0.0500,-0.8875,-2.6844,-2.2406,-1.3906
    0.25,-0.5031,-0.0625,-1.0594,-3.2031,-2.6719,-1.6625

This illustration is too short to analyze. A real recording needs at least 30 rows and complete pulse windows. The local version accepts up to 100,000 rows per recording and never downsamples; explicitly split longer recordings or extend and validate the implementation.

Minimal experiment JSON:

    {
      "schema_version": 1,
      "title": "Synthetic open-circuit example",
      "defaults": {
        "time_column": "Time_s",
        "voltage_units": "mV",
        "area_cm2": 0.33,
        "current_low_uA": -1,
        "current_high_uA": 1,
        "channels": [
          {"column": "Ch3", "label": "Control 1", "group": "Group A"},
          {"column": "Ch4", "label": "Control 2", "group": "Group A"},
          {"column": "Ch5", "label": "Control 3", "group": "Group A"},
          {"column": "Ch6", "label": "Example 1", "group": "Group B"},
          {"column": "Ch7", "label": "Example 2", "group": "Group B"},
          {"column": "Ch8", "label": "Example 3", "group": "Group B"}
        ]
      },
      "recordings": [
        {
          "id": "RUN1",
          "title": "Synthetic demonstration",
          "file": "recording.csv",
          "events": [
            {"label": "FSK", "time_s": 350.25},
            {"label": "INH", "time_s": 657.75},
            {"label": "ATP", "time_s": 936.5}
          ]
        }
      ]
    }

All example values must be checked against the actual experiment. Paths resolve beside the JSON. Per-recording fields replace matching defaults fields; nested objects such as analysis are replaced, not deeply merged with defaults.analysis. Unspecified analysis settings use the method defaults below.

Additional fields:

- skip_header_lines: metadata lines before the actual column header; default 0.
- delimiter: comma, tab ("\t") or semicolon. Omit to detect.
- pulse_onsets_s: explicit ascending sample-aligned onset times, replacing automatic detection.
- analysis: optional method settings below. The reference index is the position in channels, not the acquisition channel number.

    {
      "reference_channel": 0,
      "negative_threshold_mV": 0.12,
      "median_window_s": 6.25,
      "minimum_phase_samples": 2,
      "pulse_window_s": 2.25,
      "baseline_start_before_s": 2.0,
      "baseline_end_before_s": 0.5,
      "annotation_flag_s": 5.0,
      "asymmetry_fraction": 0.15,
      "minimum_delta_mV": 0.000001
    }

At 4 Hz, baseline includes seven samples from 2.0 to 0.5 s before onset; the pulse window includes ten samples from onset through onset +2.25 s. The median window is rounded to an odd number of samples. Baseline and pulse-window boundaries must align with acquired samples.

ΔVpp is the maximum minus minimum across both pulse phases. Asymmetry is abs((max + min)/2 − baseline)/ΔVpp. Flags also mark nearby annotations and windows without both phases around baseline. These checks are diagnostics, not proof that every automatic detection is correct.

Review outputs:

- traces.xlsx: native charts, original numeric source sheets, formula-based calculations and editable calibration.
- *_Voltage.png, *_Ieq.png: scientific plot overviews generated with Matplotlib.
- *_pulse_review.png: early, middle and late windows; green baseline, blue pulse interval.
- Results.md, verification.json: QC notes and independent saved-value checks.
- inputs/ and experiment.json: original selected exports and reproducible settings.
- analysis.json, chart_specs.json, run.log: implementation support; normally do not load these into model context.

Changing area or current in Excel updates formulas and linked charts. Fixed chart axis limits and the separate PNG images do not automatically rescale; rerun the generator when changing calibration for final figures. Changing detection settings always requires rerunning.
