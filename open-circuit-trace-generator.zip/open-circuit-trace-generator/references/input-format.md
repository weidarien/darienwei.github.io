# Input format and method settings

The local form accepts one recording per run. JSON configuration supports 1–8 recordings in one workbook, 1–12 channels per recording, and 1–4 groups. Recordings can have different calibration and channel assignments.

CSV, TSV or TXT files must use UTF-8, a unique header row and finite numeric values. Comma, tab and semicolon delimiters are supported. Decimal separators must be periods. Time is seconds, strictly increasing and uniformly sampled. Extra unselected columns remain in the retained original file. Empty selected values, missing timepoints and duplicates stop the run instead of being repaired silently.

Example data:

    Time_s,Ch3,Ch4,Ch5,Ch6,Ch7,Ch8
    0,-0.4219,-0.0500,-0.8875,-2.6844,-2.2406,-1.3906
    0.25,-0.5031,-0.0625,-1.0594,-3.2031,-2.6719,-1.6625

This illustration is too short to analyze. A real recording needs at least 30 rows and complete pulse windows. The local version accepts up to 100,000 rows per recording and never downsamples; explicitly split longer recordings or extend and validate the implementation.

Minimal experiment JSON:

    {
      "schema_version": 1,
      "title": "Synthetic open-circuit example",
      "defaults": {
        "time_column": "Time_s",
        "voltage_units": "mV",
        "area_cm2": 0.33,
        "current_low_uA": -1,
        "current_high_uA": 1,
        "channels": [
          {"column": "Ch3", "label": "Control 1", "group": "Group A"},
          {"column": "Ch4", "label": "Control 2", "group": "Group A"},
          {"column": "Ch5", "label": "Control 3", "group": "Group A"},
          {"column": "Ch6", "label": "Example 1", "group": "Group B"},
          {"column": "Ch7", "label": "Example 2", "group": "Group B"},
          {"column": "Ch8", "label": "Example 3", "group": "Group B"}
        ]
      },
      "recordings": [
        {
          "id": "RUN1",
          "title": "Synthetic demonstration",
          "file": "recording.csv",
          "events": [
            {"label": "FSK", "time_s": 350.25},
            {"label": "INH", "time_s": 657.75},
            {"label": "ATP", "time_s": 936.5}
          ]
        }
      ]
    }

All example values must be checked against the actual experiment. Paths resolve beside the JSON. Per-recording fields replace matching defaults fields; nested objects such as analysis are replaced, not deeply merged with defaults.analysis. Unspecified analysis settings use the method defaults below.

Additional fields:

- skip_header_lines: metadata lines before the actual column header; default 0.
- delimiter: comma, tab ("\t") or semicolon. Omit to detect.
- pulse_onsets_s: explicit ascending sample-aligned onset times, replacing automatic detection.
- analysis: optional method settings below. The reference index is the position in channels, not the acquisition channel number.

    {
      "reference_channel": 0,
      "negative_threshold_mV": 0.12,
      "median_window_s": 6.25,
      "minimum_phase_samples": 2,
      "pulse_window_s": 2.25,
      "baseline_start_before_s": 2.0,
      "baseline_end_before_s": 0.5,
      "annotation_flag_s": 5.0,
      "asymmetry_fraction": 0.15,
      "minimum_delta_mV": 0.000001
    }

At 4 Hz, baseline includes seven samples from 2.0 to 0.5 s before onset; the pulse window includes ten samples from onset through onset +2.25 s. The median window is rounded to an odd number of samples. Baseline and pulse-window boundaries must align with acquired samples.

ΔVpp is the maximum minus minimum across both pulse phases. Asymmetry is abs((max + min)/2 − baseline)/ΔVpp. Flags also mark nearby annotations and windows without both phases around baseline. These checks are diagnostics, not proof that every automatic detection is correct.

Review outputs:

- traces.xlsx: native charts, original numeric source sheets, formula-based calculations and editable calibration.
- *_Voltage.png, *_Ieq.png: scientific plot overviews generated with Matplotlib.
- *_pulse_review.png: early, middle and late windows; green baseline, blue pulse interval.
- Results.md, verification.json: QC notes and independent saved-value checks.
- inputs/ and experiment.json: original selected exports and reproducible settings.
- analysis.json, chart_specs.json, run.log: implementation support; normally do not load these into model context.

Changing area or current in Excel updates formulas and linked charts. Fixed chart axis limits and the separate PNG images do not automatically rescale; rerun the generator when changing calibration for final figures. Changing detection settings always requires rerunning.

## TEER calibration


The same full biphasic pulse voltage and current spans provide pulse resistance in Ω:

    R = 1000 * delta_voltage_mV / (current_high_uA - current_low_uA)
    TEER_ohm_cm2 = (R - remaining_blank_ohm) * area_cm2

For −1 to +1 µA, the denominator is 2 µA. Blank resistance is supplied in Ω, before multiplying by area. Do not subtract a resistance already compensated by the instrument.

Choose one mode per recording (or in defaults):

    "teer": {"mode": "pending"}

Unknown compensation is the default. Corrected TEER cells remain blank; TEER charts show gaps and a pending notice. Pulse R and R × area remain available for inspection.

    "teer": {"mode": "already_compensated"}

Use only when the user confirms no further blank subtraction is needed. The remaining blank is explicitly 0 Ω. Calibration against a dummy membrane under matching solution conditions can justify zero remaining blank when confirmed for that experiment. Do not assume this for another experiment.

    "teer": {
      "mode": "subtract_blank",
      "blank_ohm": 100,
      "blank_ohm_by_channel": {"Ch4": 120, "Ch6": 80}
    }

These blank values are examples, not BD342 measurements. Overrides use selected CSV headers and take precedence over the common blank. Each sample needs a finite, nonnegative blank. Zero is accepted only as an explicit supplied value. Supplying blank fields with pending/already_compensated mode is rejected to avoid ambiguous or double correction.

The TEER_Calc sheet exposes pulse R, remaining blank, corrected TEER and a note for missing/invalid/nonpositive results. All finite corrected results, including negative or zero values, stay visible and are flagged for review; they are not converted into plausible positive values. TEER group means require every group sample at that pulse. This is a time course; no baseline/drug summary window is selected automatically.

Blank correction applies only to the new TEER results. The existing Ieq magnitude retains its original pulse-resistance denominator. A change to that method would require a separately agreed analysis choice.

Method reference for subtracting a measured blank before area normalization: WPI EndOhm manual, Appendix A, https://www.wpiinc.com/media/wysiwyg/pdf/EndOhm_IMs.pdf . The user must confirm which resistance remains uncompensated in their Ussing setup.

